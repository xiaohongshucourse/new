import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Star, Calendar, Users, CheckCircle, ArrowRight } from 'lucide-react'
import mainBanner from './assets/vinjo_marketing_main_banner.png'
import joanneNg from './assets/vinjo_marketing_joanne_ng.png'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-100 to-white">
      {/* Header */}
      <header className="text-center py-8">
        <div className="text-4xl font-bold text-red-600 mb-2">左左</div>
        <div className="text-sm text-gray-600">V I N J O</div>
      </header>

      {/* Main Banner Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="bg-white inline-block px-6 py-2 rounded-lg shadow-sm mb-6">
            <h1 className="text-2xl font-bold text-gray-800">2024不能错过的平台【小红书】</h1>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center max-w-6xl mx-auto">
          {/* Left side - Text content */}
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="text-6xl font-bold text-blue-900">左左</div>
              <div className="text-4xl font-bold">×</div>
              <div className="bg-red-500 text-white px-6 py-3 rounded-full text-2xl font-bold">小红书</div>
            </div>
            
            <div className="bg-yellow-400 text-black px-6 py-4 rounded-lg">
              <h2 className="text-3xl font-bold mb-2">商家实战训练营</h2>
              <div className="flex gap-4 text-sm">
                <span className="bg-gray-200 px-3 py-1 rounded">打通企业IP赛道</span>
                <span className="bg-gray-200 px-3 py-1 rounded">小红书聚光灯快</span>
                <span className="bg-gray-200 px-3 py-1 rounded">内容营销方程式</span>
                <span className="bg-red-500 text-white px-3 py-1 rounded">LIVE</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-5 h-5 text-gray-600" />
                <span className="text-lg font-semibold">9-10 DEC 2024 (8pm - 10pm)</span>
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">星期一</span>
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">星期二</span>
                <span className="text-gray-600">(线上)</span>
              </div>
            </div>
          </div>

          {/* Right side - Joanne Ng image */}
          <div className="relative">
            <div className="bg-gradient-to-br from-pink-200 to-orange-200 rounded-3xl p-8 relative overflow-hidden">
              <div className="absolute top-4 right-4 bg-red-500 text-white px-4 py-2 rounded-full text-lg font-bold">
                小红书
              </div>
              <div className="text-center">
                <div className="w-48 h-48 mx-auto mb-4 bg-white rounded-full overflow-hidden">
                  <img src={mainBanner} alt="Joanne Ng" className="w-full h-full object-cover" />
                </div>
                <div className="bg-white px-6 py-3 rounded-full inline-block">
                  <div className="text-sm text-gray-600">【小红书海外官方合作伙伴】</div>
                  <div className="text-xl font-bold">Joanne Ng</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Registration CTA */}
        <div className="text-center mt-8">
          <div className="bg-white border-2 border-gray-300 rounded-lg p-6 max-w-md mx-auto">
            <div className="text-red-500 text-lg font-semibold mb-2">💯由官方小红书海外合作伙伴亲自授课</div>
            <div className="text-gray-700 mb-4">马上点击报名 🚩</div>
            <Button className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-lg text-lg font-semibold w-full">
              点击领取免费门票
              <div className="text-sm">出席两天Live教学</div>
            </Button>
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-sm font-semibold">4.9/5 star reviews</span>
            </div>
            <div className="text-xs text-gray-600 mt-1">累计超过1000位学员见证好评，别错过最后上车名额！</div>
          </div>
        </div>
      </section>

      {/* Company Introduction */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <div className="text-2xl mb-4">🔥 "想学就跟业内第一学" 🔥</div>
            <div className="bg-red-500 text-white py-8 rounded-lg max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-2">我们是Vinjo Marketing</h2>
              <p className="text-xl mb-2">历年来我们成功帮助近千位</p>
              <p className="text-xl font-bold">在小红书做到成绩！</p>
            </div>
          </div>

          <div className="text-center mb-8">
            <p className="text-lg text-gray-700">有证明则无需说明:</p>
          </div>

          {/* Success Stories */}
          <div className="max-w-6xl mx-auto mb-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                    💡
                  </div>
                  <h3 className="text-2xl font-bold">成功帮助多家企业内训</h3>
                </div>
                <p className="text-lg text-gray-700 mb-6">帮助他们轻松开始小红书 并做到成绩</p>
                
                {/* Company logos grid would go here */}
                <div className="grid grid-cols-4 gap-4">
                  {/* Placeholder for company logos */}
                  {[...Array(16)].map((_, i) => (
                    <div key={i} className="w-16 h-16 bg-gray-200 rounded-full"></div>
                  ))}
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-red-500 text-white px-6 py-3 rounded-full text-2xl font-bold inline-block mb-4">
                  小红书
                </div>
                <div className="text-2xl font-bold text-yellow-600">小红书の王 商家实战训练营</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Strategies Section */}
      <section className="py-16 bg-gradient-to-r from-blue-50 to-yellow-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="text-4xl">📱</div>
                  <div>
                    <h2 className="text-3xl font-bold text-gray-800">掌握2024最新玩法·趋势·策略</h2>
                    <p className="text-lg text-gray-600 mt-2">于2023年10月26日被官方小红书邀请前往内训</p>
                  </div>
                </div>
                
                {/* Photo collage placeholder */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="h-32 bg-gray-200 rounded-lg"></div>
                  <div className="h-32 bg-gray-200 rounded-lg"></div>
                  <div className="h-32 bg-gray-200 rounded-lg"></div>
                  <div className="h-32 bg-gray-200 rounded-lg"></div>
                </div>
              </div>
              
              <div className="relative">
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold">
                  1
                </div>
                <div className="bg-white rounded-3xl p-8 shadow-lg">
                  <div className="w-full h-96 bg-gray-200 rounded-2xl mb-4"></div>
                  <div className="text-center">
                    <div className="text-sm text-gray-600 mb-2">【分享课题】小红书的好攻略，您好！我们为工作需要而来，请您协助我们在10月26日1100至小红书公司，公司地址：</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Button className="bg-red-500 hover:bg-red-600 text-white px-8 py-4 rounded-lg text-lg font-semibold">
              马上报名参加2天线上【小红书实战训练营】
            </Button>
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">国内外企业顾客见证:</h2>
          
          {/* Company logos grid */}
          <div className="grid grid-cols-4 md:grid-cols-8 gap-6 max-w-6xl mx-auto mb-16">
            {[...Array(32)].map((_, i) => (
              <div key={i} className="w-20 h-20 bg-gray-200 rounded-full border-2 border-gray-300"></div>
            ))}
          </div>
        </div>
      </section>

      {/* Training Benefits */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-orange-600">
        <div className="container mx-auto px-4">
          <div className="bg-red-700 text-white py-8 px-6 rounded-lg max-w-4xl mx-auto text-center">
            <div className="text-3xl font-bold mb-4">小红书 8大独门秘籍</div>
            <div className="text-xl mb-2">2天线上训练营 传授给你</div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto mt-12">
            {[
              "引流秘籍，突破流量可复制化的引流技巧！",
              "手把手教你做一个赚钱的小红书🔥账号",
              "打造优质笔记的技巧，教你做出100%爆款✨笔记！",
              "让你快速找到自己的品牌/个人定位，轻松从众多博主中脱颖而出",
              "掌握3种定位方向，让粉丝看了就忍不住点关注！",
              "4步玩转搜索🔍 提高用户质量，如何与用户互动增强粉丝粘性",
              "告别传统式宣传手法👋，用小红书🔥帮你的品牌做推广和引流！",
              "如何通过【小红书🔥】提高笔记曝光率，少走弯路直接发笔记！"
            ].map((benefit, index) => (
              <div key={index} className="bg-white border-4 border-red-500 rounded-lg p-6">
                <p className="text-gray-800 font-semibold">{benefit}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <div className="bg-red-500 text-white py-4 px-8 rounded-lg max-w-md mx-auto">
              <div className="text-xl font-bold">无需付费，我们免费教你</div>
              <div className="text-sm">限定100位认真学习的学员·点击报名</div>
            </div>
          </div>
        </div>
      </section>

      {/* Student Reviews */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">学员好评</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {[
              { name: "celeste tan", rating: 5, review: "我的大家，这两天布局做号设定等内容等等，七个上他的助教团队成就课程。" },
              { name: "Stacy", rating: 5, review: "我是来自Newman Idesign的Stacy，透过这两天的课程，我学习到了他思维和从众理念。eg：不是思考为什么audience没有买产品而是Audience为什么要买产品。" },
              { name: "ManLee陈敏莉", rating: 5, review: "我是来自在新加坡的房产经纪的【敏莉】，透过两天的课程，我学习到无可否认的小红书是2025年的新趋势，通过广告可以拿到新客户" },
              { name: "YuMin Perodua Seremban", rating: 5, review: "我来自汽车行业的YuMin，透过2天课程，我学习到，不能盲目操作，而是要学习布局，设计好funnel，开始中草，才能帮助小红书的力量来变现，是一个长期打造个人品牌的一个好地方。" }
            ].map((review, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gray-300 rounded-full"></div>
                  <div>
                    <div className="font-semibold">{review.name}</div>
                    <div className="flex">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 text-sm">{review.review}</p>
                <Button variant="outline" size="sm" className="mt-4">Read more</Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">谁适合出席这个训练营？</h2>
          
          <div className="max-w-4xl mx-auto space-y-6">
            {[
              {
                title: "不想的时代淘汰的创业家/企业家",
                description: "可以透过小红书打造个人的IP。也能透视目前华文市场的动向。并且透过理解进行商业布局，提前预判好趋势，帮助企业蒸蒸日上。"
              },
              {
                title: "想做到成绩的公司营销负责人📈",
                description: "之前尝试了很多方式但是却不Work? 方法不对，努力白费！这个训练营将会让你了解最实战的小红书玩法！"
              },
              {
                title: "想透过小红书爆红的素人/Content Creator 🔥",
                description: "想要让自己的笔记让更多人看见，让自己的粉丝量提高？没问题，我们将会与你分享如何在短期内打造你的粉丝群，找到属于你的赛道！"
              }
            ].map((item, index) => (
              <div key={index} className="bg-pink-50 rounded-lg p-8">
                <div className="flex items-start gap-4">
                  <CheckCircle className="w-8 h-8 text-red-500 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold text-gray-800 mb-3">{item.title}</h3>
                    <p className="text-gray-700">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <div className="bg-red-500 text-white py-6 px-8 rounded-lg max-w-2xl mx-auto">
              <div className="text-2xl font-bold mb-2">无需付费，我们免费教你</div>
              <div className="text-lg">限定100位认真学习的学员·点击报名</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">Copyrights 2024 | Mantul Marketing Sdn Bhd | Terms & Conditions</p>
        </div>
      </footer>

      {/* WhatsApp Float Button */}
      <div className="fixed bottom-6 right-6">
        <div className="w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:bg-green-600 transition-colors">
          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.893 3.488"/>
          </svg>
        </div>
      </div>
    </div>
  )
}

export default App

