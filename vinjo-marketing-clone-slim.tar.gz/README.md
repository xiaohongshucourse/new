# Vinjo Marketing Clone

A recreation of the Vinjo Marketing website for their 小红书 (Xiaohongshu/Little Red Book) training camp.

## Features

- Responsive design that works on desktop and mobile
- Modern React application built with Vite
- Tailwind CSS for styling
- Chinese language content preserved from original
- Interactive elements and smooth animations

## Live Demo

Visit the live website: [GitHub Pages URL will be available after deployment]

## Local Development

1. Clone this repository
2. Install dependencies:
   ```bash
   pnpm install
   ```
3. Start the development server:
   ```bash
   pnpm run dev
   ```
4. Open http://localhost:5173 in your browser

## Deployment

This project is configured for automatic deployment to GitHub Pages using GitHub Actions.

## Build

To build for production:
```bash
pnpm run build
```

## Technologies Used

- React 18
- Vite
- Tailwind CSS
- Lucide React Icons
- shadcn/ui components

